Package consists of  Basic Signal Processing algorithms and Communication 
modulation and demodulation techniques. It includes functions to evaluate Linear
convolution,Circular convolution, Discrete fourier transform, Auto-Correlation,
Cross-Correlation, Fir filter, IIR filter, ASK, FSK, PSK, DPSK,QPSK,16QAM and TDM
modulation and demodulation techniques.The package helps students to conduct 
DSP Lab(18ECL57)  and DCOM Lab(18ECL67)programs pertaining to VTU 2018-CBCS 
scheme with ease.